package com.makina.collect.android.listeners;

public interface WidgetAnsweredListener {
	public void setAnswerChange (boolean hasChanged);
	public void updateView ();
}
